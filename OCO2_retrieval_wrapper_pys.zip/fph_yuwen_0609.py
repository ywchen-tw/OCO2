class L2:
    def __init__(self,lua,sounding_id,met,l1b,l2p,absco,radiance=False,verbose=False):
        import full_physics
        import numpy as np
        from time import time as clock
        import os
        wgt    = [ 0.02644862,  0.05288816,  0.0528518 ,  0.05280645,  0.05277458,\
                   0.05274893,  0.05272625,  0.05270206,  0.05267412,  0.05264792,\
                   0.05262494,  0.0525952 ,  0.05255694,  0.05251579,  0.05249457,\
                   0.05247313,  0.05243986,  0.05242159,  0.0524083 ,  0.02620078 ]
        
        if verbose: print("Start L2 run...")

        # l2_fp_obj.state_vector.state_vector_name contains state vector elements

        os.environ['co2_pr_file'] = l2p
        
        # create retrieval instance (and initialize state vector)
        l2_fp_obj = full_physics.L2Run(
            lua, sounding_id, met, l1b, 
            abscodir = absco)
    
        #log_timing = full_physics.fp.LogTiming()
    
        l2_fp_obj.forward_model.setup_grid()
    
        # this turns off the log:
        l2_fp_obj.config.logger.turn_off_logger()
    
        # set a-priori and initial estimate based on state vector initialization
        x_a = np.copy(l2_fp_obj.state_vector.state)
        x_i = np.copy(x_a)
        cov_a = np.copy(l2_fp_obj.state_vector.state_covariance)
    
        # get file handle for output
        out, outerr = l2_fp_obj.config.output()
        
        success = False
        try:
            t0  = clock()
            res = l2_fp_obj.solver.solve(x_i, x_a, cov_a)
            l2_fp_obj.state_vector.update_state(
                l2_fp_obj.solver.x_solution, 
                l2_fp_obj.solver.aposteriori_covariance);
            t1  = clock()
    
            if(res):
                out.write()
                xco2=np.sum(l2_fp_obj.solver.x_solution[0:20]*1e6*np.array(wgt))
                sp  =l2_fp_obj.solver.x_solution[21]
                oa  =l2_fp_obj.solver.x_solution[35]
                wa = l2_fp_obj.solver.x_solution[37] # albedo weak
                sa = l2_fp_obj.solver.x_solution[39] # albedo strong
                oe = l2_fp_obj.solver.x_solution[47] # oxygen eof
                we = l2_fp_obj.solver.x_solution[50] # weak eof
                se = l2_fp_obj.solver.x_solution[53] # strong eof
                
                ob = l2_fp_obj.solver.x_solution[38] # BRDF intercept
                wb = l2_fp_obj.solver.x_solution[40] # BRDF intercept
                sb = l2_fp_obj.solver.x_solution[42] # BRDF intercept
                h2o= l2_fp_obj.solver.x_solution[20] # H2O scaling factor
                
                #tp = l2_fp_obj.solver.x_solution[:].copy()
                runt=(t1-t0)/60.
                if verbose:
                    print("Found Solution in ",runt,' minutes.')
                    print("XCO2=",xco2)
                    print("psur=",sp)
                success = True
            else:
                if verbose:
                    print("Failed to find solution")
                xco2=-1   
                sp  =-1
                ob  =-1
                wb  =-1
                sb  =-1
                h2o =-1
                o2a =-1
                wl  =-1
                L0  =-1
                runt=-1
        except:
            import traceback
            traceback.print_exc()
            outerr.write_best_attempt()
    
        if radiance & success:
            t0=clock()
            # Calculate radiances
            X_0 = l2_fp_obj.forward_model.radiance_all(True)
            # Get radiance and wavelengths
            L0  = X_0.spectral_range.data.copy()
            wl  = X_0.spectral_domain.data.copy()
            t1=clock()
            radt=(t1-t0)/60
            rad=(wl,L0)
        else:
            radt=None
            rad =None
    
        # Force flush of output
        out = None
        l2_fp_obj = None
        
        self.xco2 = xco2
        self.psur = sp
        self.oa   = ob
        self.wa   = wb
        self.sa   = sb        
        self.h2o  = h2o
        self.dt   = runt

        if success:   
            pass
    
if __name__=='__main__':

    test = False
    if test:
        lua='../dat/custom_config.lua'
        snd='2015062217243604' 
        met='../dat/oco2_L2MetND_05176a_150622_B10003r_191113232812.h5'
        l1b='../dat/oco2_L1bScND_05176a_150622_B10003r_191113232757.h5'
        l2p='../dat/oco2_L2CPrND_05176a_150622_B10003r_191114002650.h5'
        abscodir= '/opt/local/oco/absco' 
        l2       =  L2(lua,snd,met,l1b,l2p,abscodir,radiance=False,verbose=True)
    else:
        import sys,os
        #import full_physics
        #sys.exit('successfully imported full_physics')
        args=len(sys.argv)
        if args==8:
            lua      = sys.argv[1]
            snd      = sys.argv[2]
            met      = sys.argv[3]
            l1b      = sys.argv[4]
            prior    = sys.argv[5]
            abscodir = sys.argv[6]
            merradir = sys.argv[7]
            print('1',prior)
            l2         =  L2(lua,snd,met,l1b,prior,abscodir,radiance=False,verbose=True)
            print('2')
            
            if os.path.isfile('tmp.csv'):
                os.system('rm tmp.csv')
            handle = open('tmp.csv','w')
            handle.write('SND, '+snd+'\n')
            handle.write('XCO2, '+str(l2.xco2)+'\n')
            handle.write('PSUR, '+str(l2.psur)+'\n')
            handle.write('OA, '+str(l2.oa)+'\n')        
            handle.write('WA, '+str(l2.wa)+'\n')        
            handle.write('SA, '+str(l2.sa)+'\n')        
            handle.write('H2O, '+str(l2.h2o)+'\n')        
            handle.write('DT, '+str(l2.dt)+'\n')        
            handle.close()
        else:
            print(sys.argv[0],' called with the wrong arguments.')

    
