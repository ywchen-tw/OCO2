"""
Author: Sebastian Schmidt, 7/2020
Adapted from /Users/schmidt/rtm/ocosim/py/ret09single.py
Modified by Yu-Wen Chen, 6/2022

Information for download of data can be found here:
    https://disc.gsfc.nasa.gov/data-access#windows_wget

"""

import os,h5py
import OCO_v4 as OCO
import numpy as np
import csv
from sys import exit as ext

def readcfg(file,ws=True,remove_underscore=True):
    """
    Read information from configure csv file
    """
    if ws:
        handle=open(file,'rU')
    else:
        handle=open(file,'r')


    lines = csv.reader(handle, delimiter=',',dialect='excel')

    # read cfg file and put into dictionary
    content = {}
    for items in lines:
        if len(items)>0:
            if len(items[0])>0:
                key=str(items[0])
                if len(items)>1:
                    if len(items[1])>0:
                        info=[]
                        proceed=True
                        for item in items[1:]:
                            if (len(item)>0) & proceed:
                                if item[0]=='#':    # get rid of end-line comments
                                    proceed=False
                                else:
                                    if (item[0]=='_') & remove_underscore:
                                        add = item[1:]
                                    else:
                                        add = item
                                    info.append(add)
                            if len(info)==1:
                                content[key]=info[0]
                            else:
                                content[key]=info
    # SNDs are all combined as a separate dictionary
    snd={}; rms=[]
    for i,key in enumerate(content):
        if ('SND' in key) & (len(key)==19):
            snd[key[3:]]=content[key]
            rms.append(key)
    for rm in rms:
        del content[rm]
    if len(snd)>0:
        content['snd']=snd
    return(content) 


###########################################################################
# SETTINGS
workstation = False    # running on workstation or locally
retrieve    = True     # do retrieval
modified    = False     # make & retrieve unperturbed spectrum
save_each   = True     # save retrieval result for each sounding
verbose     = True

if os.environ['HOME']=='/home/schmidt': workstation=True
if workstation: # import additional modules to do retrievals and for communication
    path     = '../dat/'           # path of configuration file and output directory
    cfg      = path+'20150622_30km_o2a_wco2.csv'       # configuration filename and path
    OutDir   = path+'output/20150622_30km_o2a_wco2/'    # path for directory of output files
    res      = OutDir+'full-unmodified_'+'20150622_30km_o2a_wco2'+'.h5'   # output file path and name
    lua      = path+'custom_config.lua'
    merradir = '/opt/local/oco/merra'
    abscodir = '/opt/local/oco/absco' 
else: # setting for local computer
    path    = '/Users/schmidt/rtm/ocosim/dat/'
    cfg     = '../dat/20150622.csv'
    res     = '../dat/20150622.h5'

# check whether output directory exsists; create a new one if it doesn't exist
if not os.path.isdir(OutDir):
    os.system(f'mkdir {OutDir}')

import subprocess
output = subprocess.check_output("echo $0",shell=True).decode('utf-8')
ind=output.rfind('/')
if ind>0: output=output[ind+1:]
print('Shell used: '+output)
 
"""
specify soundings to retrieve
"""
inf    = readcfg(cfg,ws=workstation)
path   = inf['pathdat']
ocol2f = inf['l2']
ocoltf = inf['lt']
l1bf   = path+inf['l1b']
priorf = path+inf['prior']
metf   = path+inf['met']
solf   = path+inf['sol']
python = 'python'

snds=[]
for key in inf['snd'].keys():
    snds.append(key)
snds = list(np.sort(snds))

"""
Overwrite soundings from csv (if required for testing)
"""
#snds=[]


"""
Run the retrieval code
"""
if workstation & retrieve:
    """
    Perturb/unperturb here if the below is true

    Unperturb mode: Remove 3D effect from radation
    Perturb mode  : Add 3D effect on radiaiton
    """
    if modified: # Retrieval with modified L1B file
        l1b = OCO.L1B(l1bf)
        l1b.add_solar(solf)
        syn = OCO.L1U(l1b)
        for snd0 in snds:
            l2f = f'{OutDir}/reto_{snd0}.h5'
            if os.path.isfile(l2f):
                print(l2f+' already exists, skipping unperturbing')
                l1b_retrieve=l1bf
            else:
                print('Rescaling '+snd0+' with '+str(inf['snd'][snd0][4:10]))
                o2   = np.float_(inf['snd'][snd0][4:6]) # a' and b' coefficients
                wco2 = np.float_(inf['snd'][snd0][6:8])
                sco2 = np.float_(inf['snd'][snd0][8:10])
                print('o2 a, b:', o2)
                print('wco2 a, b:', wco2)
                print('sco2 a, b:', sco2)
                syn.perturb(snd0,o2=o2,wco2=wco2,sco2=sco2,mode='unperturb') # These two steps are done 
                syn.substitute()                                                # one sounding at a time
            l1b_retrieve=syn.l1uf
    else: # Just standard retrieval without perturbations
        l1b_retrieve=l1bf
        print(l1bf)

    """
    Start getting retrieval 
    """
    out={}
    print('Using '+l1b_retrieve)
    for snd in snds:
        l2f = f'{OutDir}/reto_{snd}.h5'
        print('Retrieving '+str(snd))
        if os.path.isfile(l2f):
            print(l2f+' already exists, skipping retrieval')
            out[snd]= [l2f,-1,-1,-1,inf['snd'][snd][:]]
        else:
            try:
                cmd=python+' fph_yuwen_0609.py '+lua+' '+snd+' '+metf+' '+l1b_retrieve+' '+priorf+' '+abscodir+' '+merradir
                print('Executing:'+cmd)
                os.system(cmd) # This is the actual retrieval
                if(os.path.isfile('out.h5') & os.path.isfile('tmp.csv')):
                    os.system('mv out.h5 '+l2f) 
                    tmp=readcfg('tmp.csv')
                    out[snd]= [l2f,tmp['XCO2'],tmp['PSUR'],tmp['DT'],inf['snd'][snd][:]]
                else:
                    print('retrieval did not finish; status of out.h5 and tmp.csv:')
                    print(os.path.isfile('out.h5'))
                    print(os.path.isfile('tmp.csv'))
                    out[snd]= [l2f,-2,-2,-2,inf['snd'][snd][:]]
            except:
                print('os.system error')
                out[snd]= [l2f,-2,-2,-2,inf['snd'][snd][:]]
            if (out[snd][1] == -2):
                h5=h5py.File(l2f,"w")
                print(snd)
                h5['snd']=str(snd)
                h5['error']=-2
                h5.close()
        
"""
Collect the output data from retrieval output files
"""
if workstation and retrieve: 
    print('Collect retrieval files...')
    for key in snds: # This is the problem; should go through in better order
        print('Collecting...'+key)
        if out[key][1] ==-2:
            out[key].append(out[key][1]) # error message from retrieval code
        else:
            l2f = out[key][0]
            if(os.path.isfile(l2f)):
                h5=h5py.File(l2f,'r')
                if 'error' in h5.keys():
                    e=h5['error'][...]
                    print('error code '+str(e))
                    out[key].append([e,e,e,e,e,e])
                else:
                    psur =h5['/RetrievalResults/surface_pressure_fph'][0]
                    xco2=h5['/RetrievalResults/xco2'][0]*1e6
                    aod =h5['/RetrievalResults/aerosol_total_aod'][0]
                    rfl1=h5['/RetrievalResults/brdf_reflectance_o2'][0]
                    rfl2 =h5['/RetrievalResults/brdf_reflectance_weak_co2'][0]
                    rfl3 =h5['/RetrievalResults/brdf_reflectance_strong_co2'][0]
                    print(xco2,psur,aod,rfl1,rfl2,rfl3)
                    out[key].append([xco2,aod,rfl1,rfl2,rfl3,psur])
                h5.close()
            else:
                print('Retrieval file not found')
                out[key].append(-3)
    """
    Save it all after processing
    """
    h5=h5py.File(res,"w")    
    h5snd=[]; xco2w=[]; psurw=[]; time=[]; lon=[]; lat=[]; l2xco2=[]; f_xco2=[]; f_aod=[]; f_rfl1=[]; f_rfl2=[]; f_rfl3=[]; f_psur=[]; mtpsur=[]
    f_o2=[]; f_wco2=[]; f_sco2=[]
    for key in snds:
        h5snd.append(int(key))
        xco2w.append(float(out[key][1]))
        psurw.append(float(out[key][2]))
        time.append(float(out[key][3]))
        lon.append(float(out[key][4][0]))
        lat.append(float(out[key][4][1]))
        l2xco2.append(float(out[key][4][2]))
        mtpsur.append(float(out[key][4][3]))
        if modified:
            f_o2.append([float(out[key][4][4]), float(out[key][4][5])])
            f_wco2.append([float(out[key][4][6]), float(out[key][4][7])])
            f_sco2.append([float(out[key][4][8]), float(out[key][4][9])])
        else:
            f_o2.append([0,0])
            f_wco2.append([0,0])
            f_sco2.append([0,0])
        if type(out[key][5]) is int:
            print('error code for '+key+':')
            print(out[key][5])
            f_xco2.append(-2)
            f_aod.append(-2)
            f_rfl1.append(-2)
            f_rfl2.append(-2)
            f_rfl3.append(-2)
            f_psur.append(-2)
        else:
            f_xco2.append(out[key][5][0])
            f_aod.append(out[key][5][1])
            f_rfl1.append(out[key][5][2])
            f_rfl2.append(out[key][5][3])
            f_rfl3.append(out[key][5][4])
            f_psur.append(out[key][5][5])
    h5['snd']=h5snd
    h5['xco2_weighted_column']=xco2w
    h5['cpu_minutes']=time
    h5['lon']=lon
    h5['lat']=lat
    h5['xco2_L2_file']=l2xco2
    h5['psur_MT_file']=mtpsur
    h5['psur_retrieved']=f_psur
    h5['xco2_retrieved']=f_xco2
    h5['aod']=f_aod
    h5['rfl1']=f_rfl1
    h5['rfl2']=f_rfl2
    h5['rfl3']=f_rfl3
    h5['pert_o2']=f_o2
    h5['pert_wco2']=f_wco2
    h5['pert_sco2']=f_sco2
    h5.close()

"""
Delete separate sounding retrieval result files
"""
if not save_each:
    print('Deleting separate retrieval files')
    for snd in snds:
        l2f = f'{OutDir}/reto_{snd}.h5'
        if os.path.isfile(l2f):
            os.system(f'rm {l2f}')
            print(l2f+' is been deleted!')


