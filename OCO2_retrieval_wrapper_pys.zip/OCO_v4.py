"""
Modules for OCO files (for retrieval module, check fpo)
"""
import h5py
import numpy as np
import sys,os
if sys.version_info[0]<3: from fpo import print2
else: from p3 import print2   
import matplotlib.pyplot as plt

###########################################################################  
class DIA:
    def __init__(self, file, snd,verbose=False):
        if verbose: print2('Reading '+file+'...',flush=True)
        handle    = h5py.File(file,'r')
        self.diaf = file
        self.id   = handle["RetrievalHeader/sounding_id"][...]
        self.wl   = handle["SpectralParameters/wavelength"][...]
        self.rado = handle["SpectralParameters/measured_radiance"][...]
        self.radc = handle["SpectralParameters/modeled_radiance"][...]
        self.dmlt = handle["PreprocessingResults/dispersion_multiplier_abp"][...] # dispersion multiplier - used later
        self.xco2 = handle["RetrievalResults/xco2"][...]
        self.psur = handle["RetrievalResults/surface_pressure_fph"][...]
        handle.close()

        self.n    = len(self.id)  # number of spectra
        # extract information for specific sounding:
        idx       = np.argmin(np.abs(int(snd)-self.id))
        self.wl   = self.wl[idx,:] 
        self.id   = self.id[idx]
        self.rado = self.rado[idx,:]
        self.radc = self.radc[idx,:]  
        self.dmlt = self.dmlt[idx]
        self.xco2 = self.xco2[idx]*1e6
        self.psur = self.psur[idx]*0.01        

        # separate the three OCO bands
        i1 = np.where((self.wl < 1.0) & (self.rado > 0))
        i2 = np.where((self.wl > 1.0) & (self.wl < 2.0) & (self.rado>0))
        i3 = np.where((self.wl > 2.0) & (self.rado >0))
        self.wl1   = self.wl[i1]
        self.wl2   = self.wl[i2]
        self.wl3   = self.wl[i3]
        self.rado1 = self.rado[i1]
        self.radc1 = self.radc[i1]        
        self.rado2 = self.rado[i2]
        self.radc2 = self.radc[i2]        
        self.rado3 = self.rado[i3]
        self.radc3 = self.radc[i3]   
        
    def add_l1b(self,file,verbose=False): # add L1B information
        self.l1bf = file
        l1b=L1B(file,self.id,self.dmlt,verbose=verbose)
        self.l1b=l1b
                
    def add_l2(self,l2): # add l2 retrieval information
        self.l2=l2
        
    def meteorology(self,file,verbose=False):
        if verbose: print2('Check for '+file+'...',flush=True)
        if len(file) < 1: sys.exit("No valid file: "+file)
        pos=file.rfind("V8_")
        if pos < 0: 
            pe = file.rfind("_ECMWF")
            if pe < 0: sys.exit("""Did not find "V8" or "ECMWF" in file name - make sure you use valid reanalysis file.""")
            self.ecmwf = file
            self.met   = file
        else: # working with GMAO instead of ECMWF - need to convert format.
            path=file[0:pos]
            name=file[pos+3:]
            fmet=path+name
            self.gmao = fmet
            self.met  = file
            if not os.path.isfile(file): # check if "V8" or ECMWF file already exists
                if not os.path.isfile(fmet): sys.exit('File '+fmet+' missing - please download.')
                if verbose: print2('Converting',fmet,'-->',file,'...')   
                self.gmao2ecmwf()

    def gmao2ecmwf(self):        
        met={"meteorology_flag"             : "ecmwf_flag",
             "ozone_profile_met"            : "ozone_profile_ecmwf",
             "skin_temperature_met"         : "skin_temperature_ecmwf",
             "specific_humidity_profile_met": "specific_humidity_profile_ecmwf",
             "surface_pressure_met"         : "surface_pressure_ecmwf",
             "temperature_profile_met"      : "temperature_profile_ecmwf",
             "total_column_water_vapor_met" : "total_column_water_vapor_ecmwf",
             "two_meter_temperature_met"    : "two_meter_temperature_ecmwf",
             "vector_pressure_levels_met"   : "vector_pressure_levels_ecmwf",
             "windspeed_u_met"              : "windspeed_u_ecmwf",
             "windspeed_v_met"              : "windspeed_v_ecmwf"}
        dim={"MetLevel"                     : "ECMWFLevel"}
        
        if os.path.isfile(self.met): sys.exit(self.met+' exits - please delete first')
        os.system("cp "+self.gmao+" "+self.met) # copy gmao file to "met" file.
        oco = h5py.File(self.met, "r+")         # open "met" file for modifications
        
        # Copy dims
        grp=oco['/Dimensions/MetLevel/']
        x1=grp.attrs['Size']
        x2=grp.attrs['Description']
        
        dim = oco.create_group('/Dimensions/ECMWFLevel')
        dim.attrs['Size']       =x1
        dim.attrs['Description']='ECMWF Vertical Level' # x2
        
        # Copy sounding
        cnt=oco['/MeteorologyDiagnostics/sounding_gph_met'][...]
        grp=oco['/MeteorologyDiagnostics/sounding_gph_met']
        x0=grp.attrs['Shape']
        x1=grp.attrs['Units']
        x2=grp.attrs['Type']
        x3=grp.attrs['Description']
        
        oco.create_group('/ECMWFDiagnostics/')
        oco['/ECMWFDiagnostics/sounding_gph_ecmwf']=cnt
        oco['/ECMWFDiagnostics/sounding_gph_ecmwf'].attrs['Shape']       = x0
        oco['/ECMWFDiagnostics/sounding_gph_ecmwf'].attrs['Units']       = x1
        oco['/ECMWFDiagnostics/sounding_gph_ecmwf'].attrs['Type']        = x2
        oco['/ECMWFDiagnostics/sounding_gph_ecmwf'].attrs['Description'] = x3
        
        # Copy meteorology
        for key in met.keys():
            cnt = oco['/Meteorology/'+key][...]
            oco['/ECMWF/'+met[key]]=cnt        
        oco.close()
        
    def plot_l2(self,file=None):
        import matplotlib
        matplotlib.use('Agg') # This ensures that figure can be made without X display
        import matplotlib.pyplot as plt 
        f0,p=plt.subplots(3,1,figsize=(7,7)); f0.subplots_adjust(hspace=0.5)
        p[0].plot(self.wl1,self.rado1); p[0].plot(self.wl1,self.radc1); p[0].set_title('psur='+str(np.round(self.psur,1))+' hPa')
        p[0].plot(self.l2.wl1,self.l2.radc1,label='Calculated'); p[0].set_ylabel('O2 Radiance')
        p[1].plot(self.wl2,self.rado2); p[1].plot(self.wl2,self.radc2); p[1].set_title('XCO2='+str(np.round(self.xco2,2)))
        p[1].plot(self.l2.wl2,self.l2.radc2,label='Calculated'); p[1].set_ylabel('WCO2 Radiance')
        p[2].plot(self.wl3,self.rado3); p[2].plot(self.wl3,self.radc3); p[2].set_title('R-XCO2='+str(np.round(self.l2.xco2,2)))
        p[2].plot(self.l2.wl3,self.l2.radc3,label='Calculated'); p[2].set_ylabel('SCO2 Radiance')
        p[2].set_xlabel('Wavelength [$\mu$m]')
        if file != None: f0.savefig(file)
        
    def plot_dia(self,file=None):
        import matplotlib.pylab as plt
        print('yes')
        f0,p=plt.subplots(3,1,figsize=(7,7))
        print('no')
        f0.subplots_adjust(hspace=0.5)
        p[0].plot(self.wl1,self.rado1)
        p[0].plot(self.wl1,self.radc1)
        p[0].set_title('psur='+str(np.round(self.psur,1))+' hPa')
        p[0].plot(self.l1b.wl1,self.l1b.rad1,linewidth=0.5)
        p[0].set_ylabel('O2 Radiance')
        p[1].plot(self.wl2,self.rado2)
        p[1].plot(self.wl2,self.radc2)
        p[1].set_title('XCO2='+str(np.round(self.xco2,2)))
        p[1].plot(self.l1b.wl2,self.l1b.rad2,linewidth=0.5)
        p[1].set_ylabel('WCO2 Radiance')
        p[2].plot(self.wl3,self.rado3)
        p[2].plot(self.wl3,self.radc3)
        p[2].plot(self.l1b.wl3,self.l1b.rad3,linewidth=0.5)
        p[2].set_ylabel('SCO2 Radiance')
        p[2].set_xlabel('Wavelength [$\mu$m]')
        if file != None: f0.savefig(file)
###########################################################################  

class L1B:
    def __init__(self,file,snd=None,dmlt=None,verbose=True):
        """
        Note: L1B does not have wavelengths - would need to go elsewhere to get them
        """
        if verbose: print2('Reading '+file+'...',flush=True)
        handle    = h5py.File(file,'r')
        self.file = file
        self.dis  = handle["InstrumentHeader/dispersion_coef_samp"][...]
        #self.bsl  = handle["InstrumentHeader/bad_sample_list"][...]
        sid       = handle["/SoundingGeometry/sounding_id"][...]
        rad1      = handle['/SoundingMeasurements/radiance_o2'][...]      # radiances
        rad2      = handle['/SoundingMeasurements/radiance_weak_co2'][...]
        rad3      = handle['/SoundingMeasurements/radiance_strong_co2'][...]   
        self.snd  = sid
        sza       = handle['/SoundingGeometry/sounding_solar_zenith'][...]   
        self.mu   = np.cos(np.radians(sza))
        self.ilsx = handle["InstrumentHeader/ils_delta_lambda"][...]
        self.ilsy = handle["InstrumentHeader/ils_relative_response"][...]
        handle.close()
        # wl
        # sza
        # sol - kurudz (sub functin)

        # make wavelengths
        lam = np.zeros([8,1016,3]) # Those are the wavelengths in the radiance file
        wli = np.arange(1,1017,dtype=float)
        for i in range(8): 
            for j in range(3):
                for k in range(5):
                    lam[i,:,j]=lam[i,:,j] + self.dis[j,i,k]*wli**k               
        self.wl1approx  = lam[:,:,0]
        self.wl2approx  = lam[:,:,1]
        self.wl3approx  = lam[:,:,2]
        
        # sub-setting to specific SND
        if snd is not None:
            # get footprint (1-8) for sounding (flt[0][0] is position along track; flt[1][0] footprint across track)
            flt=np.where(np.int_(sid) == int(snd))
            ft = flt[0][0]
            fp = flt[1][0]
            if dmlt is not None:
                # calculate nominal wavelength according to fixed dispersion coefficients
                lam = np.zeros([8,1016,3]) # Those are the wavelengths in the radiance file
                wli = np.arange(1,1017,dtype=float)
                for i in range(8): 
                    for j in range(3):
                        for k in range(5):
                            lam[i,:,j]=lam[i,:,j] + self.dis[j,i,k]*wli**k               
                self.wl1  = lam[fp,:,0]*dmlt
                self.wl2  = lam[fp,:,1]*dmlt
                self.wl3  = lam[fp,:,2]*dmlt
            self.rad1 = rad1[ft,fp,:]
            self.rad2 = rad2[ft,fp,:]
            self.rad3 = rad3[ft,fp,:] 
        else:
            self.rad1 = rad1[:,:,:]
            self.rad2 = rad2[:,:,:]
            self.rad3 = rad3[:,:,:] 
#        if (snd is None) & (snds is not None):
#            if verbose: print2('Subset l1b...',flush=True)
#            #self.sub(snds)
#            if verbose: print2('...done',flush=True)
            
#    def sub(self,snds):
#        idxarr=[]
##        for snd0 in snds:
##            idx=np.argmin(np.abs(int(snd0)-np.int_(self.snd)))
##            if True: #(np.abs(snd0-self.snd[idx])<0.1): 
##                idxarr.append(idx)
##            else:
##                print('Warning: missing snd in met file')
##                idxarr.append(0)
#        for snd0 in snds:
#            flt=np.where(np.int_(self.snd) == int(snd0))
#            ft = flt[0]
#            fp = flt[1]
#            print(snd0)
#            print(ft)
#            print(fp)
#            ext()
#        self.rad1  = self.rad1.flatten()[idxarr]
#        self.rad2  = self.rad2.flatten()[idxarr]
#        self.rad3  = self.rad3.flatten()[idxarr]
#        self.snd   = self.snd.flatten()[idxarr]

###########################################################################    
# read in solar file
    def add_solar(self,file,fp=0,verbose=True):
        self.solar=file
        handle = open(file,'r')
        lines  = handle.readlines() 
        handle.close()
        wl=[]
        fx=[]
        for line in lines[6:]:
            items=np.float_(line.split())
            wl.append(1e4/items[0])
            fx.append(items[1])
        wl=np.array(wl)
        fx=np.array(fx)
        idx=np.argsort(wl)
        solar_wl=np.array(wl[idx])
        solar_irradiance=np.array(fx[idx])

        ch1=np.interp(self.wl1approx[fp,:],solar_wl,solar_irradiance)
        ch2=np.interp(self.wl2approx[fp,:],solar_wl,solar_irradiance)        
        ch3=np.interp(self.wl3approx[fp,:],solar_wl,solar_irradiance)        

        ox=np.zeros(1016)
        wc=np.zeros(1016)
        sc=np.zeros(1016)
        for i in range(1016):
            temp=np.interp(self.wl1approx[fp,:],self.ilsx[0,fp,i,:]+self.wl1approx[fp,i],self.ilsy[0,fp,i,:])
            temp=temp/np.sum(temp)
            ox[i]=np.sum(ch1*temp)
            temp=np.interp(self.wl2approx[fp,:],self.ilsx[1,fp,i,:]+self.wl2approx[fp,i],self.ilsy[1,fp,i,:])
            temp=temp/np.sum(temp)
            wc[i]=np.sum(ch2*temp)
            temp=np.interp(self.wl3approx[fp,:],self.ilsx[2,fp,i,:]+self.wl3approx[fp,i],self.ilsy[2,fp,i,:])
            temp=temp/np.sum(temp)
            sc[i]=np.sum(ch3*temp)
        
        nz =self.rad1.shape[0]
        nfp=self.rad1.shape[1]
        mu = np.stack([self.mu]*1016,axis=2)
        oxs= np.stack([ox]*nfp,axis=0)
        oxs= np.stack([oxs]*nz,axis=0)
        wcs= np.stack([wc]*nfp,axis=0)
        wcs= np.stack([wcs]*nz,axis=0)
        scs= np.stack([sc]*nfp,axis=0)
        scs= np.stack([scs]*nz,axis=0)


        self.rfl1=np.pi*self.rad1/(mu*oxs)
        self.rfl2=np.pi*self.rad2/(mu*wcs)
        self.rfl3=np.pi*self.rad3/(mu*scs)
        
        
        
        print("at some point, check against 'brdf_reflectance_o2' from L2...")
        # for 2015062217102901 - should be around 0.13....but I should also retrieve this myself!
        #plt.plot(self.wl1approx[fp,:],self.rfl1[50,fp,:],'k.')
        #plt.title(str(self.snd[50,0]))
        #plt.plot(self.wl3approx[fp,:],sc,'r-')
        
class L1P:
    def __init__(self,oco,source=0,verbose=False):
        if verbose: print2('Creating perturbed L1B file...',flush=True)
        self.l1pf = COPY_AND_RENAME(oco.l1bf,'oco2_L1b','oco2_L1p') # creates L1b file copy as L1p file
        self.wl1  = oco.l1b.wl1 # The wavelengths ALWAYS come from L1B file (adjustment see dmlt, see above in L1B class)
        self.wl2  = oco.l1b.wl2
        self.wl3  = oco.l1b.wl3
        self.id   = oco.id

        if source==0: # Get L1B radiances  
            """
            Currently the only viable option.
            """
            self.rad1 = oco.l1b.rad1
            self.rad2 = oco.l1b.rad2
            self.rad3 = oco.l1b.rad3    
            
        if source==1: # Get observed spectrum from DIA and interpolate onto L1B wavelength grid
            """
            Unclear how to map back to L1B wavelength grid; would need to 
            1) establish wavelength shift
            2) Re-scale L1B spectrum so it matches the input spectrum
            3) Since this spectrum originally came from L1B, this would be the best test for how well the mapping can be done.
            """
            sys.exit('Not implemented')
            #self.rad1 = np.interp(self.wl1,oco.wl1,oco.rado1)
            #self.rad2 = np.interp(self.wl2,oco.wl2,oco.rado2)
            #self.rad3 = np.interp(self.wl3,oco.wl3,oco.rado3)

        if source==2: # Get calculated spectrum from DIA and interpolate onto L1B wavelength grid
            """
            Unclear how to map back to L1B wavelength grid; would need to 
            1) establish wavelength shift
            2) Re-scale L1B spectrum so it matches the input spectrum
            """
            sys.exit('Not implemented')

        if source==3: # Get spectrum from V7 algorithm and interpolate onto L1B wavelength grid
            """
            Unclear how to map back to L1B wavelength grid; would need to 
            1) establish wavelength shift
            2) Re-scale L1B spectrum so it matches the input spectrum
            3) Here one should know the wavelength mapping because the wl0 parameter is directly available, but not for 1016 wavelengths; there is probably no direct match there either.
            4) Perhaps the mapping works at least piece-wise.
            """
            sys.exit('Not implemented')
            
    def perturb(self,o2=[1,1],wco2=[1,1],sco2=[1,1],mode='lambda',min0=True,verbose=False):
        """
        Apply simple perturbation of L1B (L1P) spectrum
        o2,wco2,sco2 = [a,b]       : a,b indicate the scaling of the spectrum on the left/right end
        mode={'lambda','radiance'} : how to rescale (with respect to wavelength or radiance)
        """
        n1 = len(self.wl1); n2 = len(self.wl2); n3 = len(self.wl3)

        if mode == 'lambda':
            print(o2,wco2,sco2)
            r1=np.linspace(o2[0]  ,  o2[1],n1)
            r2=np.linspace(wco2[0],wco2[1],n2)
            r3=np.linspace(sco2[0],sco2[1],n3)
            self.rad1 = r1*self.rad1
            self.rad2 = r2*self.rad2
            self.rad3 = r3*self.rad3
            
        if mode == 'radiance':
            l1  = [np.min(self.rad1),np.max(self.rad1)] # limits           
            if min0: l1[0]=0                            # use min=0 instead of actual minimum
            rr  = (self.rad1-l1[0])/(l1[1]-l1[0])       # how far "right"
            ll  = 1-rr                                  # how far "left"
            r1  = ll*o2[0]+rr*o2[1]
            self.rad1 = r1*self.rad1
            
            l2  = [np.min(self.rad2),np.max(self.rad2)] # limits           
            if min0: l2[0]=0                            # use min=0 instead of actual minimum
            rr  = (self.rad2-l2[0])/(l2[1]-l2[0])       # how far "right"
            ll  = 1-rr                                  # how far "left"
            r2  = ll*wco2[0]+rr*wco2[1]
            self.rad2 = r2*self.rad2

            l3  = [np.min(self.rad3),np.max(self.rad3)] # limits           
            if min0: l3[0]=0                            # use min=0 instead of actual minimum
            rr  = (self.rad3-l3[0])/(l3[1]-l3[0])       # how far "right"
            ll  = 1-rr                                  # how far "left"
            r3  = ll*sco2[0]+rr*sco2[1]
            self.rad3 = r3*self.rad3
               
    def substitute(self,o2=True,wco2=True,sco2=True):    
        oco = h5py.File(self.l1pf, "r+")
        sid = oco['/SoundingGeometry/sounding_id'][...]       # get footprint IDs
        if o2:
            ro2 = oco['/SoundingMeasurements/radiance_o2'][...]   # get radiances
            del(oco['/SoundingMeasurements/radiance_o2'])         # delete O2 radiance measurements
        if wco2:
            rwc = oco['/SoundingMeasurements/radiance_weak_co2'][...]   # get radiances
            del(oco['/SoundingMeasurements/radiance_weak_co2'])         # delete O2 radiance measurements
        if sco2:
            rsc = oco['/SoundingMeasurements/radiance_strong_co2'][...]   # get radiances
            del(oco['/SoundingMeasurements/radiance_strong_co2'])         # delete O2 radiance measurements            
        # find retrieval footprint
        flt=np.where(np.int_(sid) == np.int_(self.id))
        if (len(flt) == 2):
            idx_x   = flt[0][0]
            idx_foot= flt[1][0]
            if o2:
                ro2_mod=ro2.copy()
                ro2_mod[idx_x,idx_foot,:]=self.rad1
                oco['/SoundingMeasurements/radiance_o2'] = ro2_mod
            if wco2:
                rwc_mod=rwc.copy()
                rwc_mod[idx_x,idx_foot,:]=self.rad2
                oco['/SoundingMeasurements/radiance_weak_co2'] = rwc_mod
            if sco2:
                rsc_mod=rsc.copy()
                rsc_mod[idx_x,idx_foot,:]=self.rad3
                oco['/SoundingMeasurements/radiance_strong_co2'] = rsc_mod
            success=True
        else:
            success=False
        oco.close()
        return(success)
        
    def reference2(self,l1b,file=None):
        import matplotlib.pylab as plt
        f0,p=plt.subplots(3,2,figsize=(7,7))
        f0.subplots_adjust(hspace=1.0)
        #f0.subplots_adjust(vspace=1.0)
        p[0,0].plot(l1b.wl1,l1b.rad1)
        p[0,0].plot(self.wl1,self.rad1)
        p[0,0].set_title(fn(self.l1pf))
        p[0,0].set_xlabel('Wavelength [micron]') 
        p[0,0].grid(color='k', linestyle='--', linewidth=0.5,axis='y',which='major')
        p[1,0].plot(l1b.wl2,l1b.rad2)
        p[1,0].plot(self.wl2,self.rad2)
        p[1,0].set_xlabel('Wavelength [micron]') 
        p[1,0].grid(color='k', linestyle='--', linewidth=0.5,axis='y',which='major')
        p[2,0].plot(l1b.wl3,l1b.rad3)
        p[2,0].plot(self.wl3,self.rad3)
        p[2,0].set_xlabel('Wavelength [micron]') 
        p[2,0].grid(color='k', linestyle='--', linewidth=0.5,axis='y',which='major')


        p[0,1].scatter(l1b.rad1,(self.rad1-l1b.rad1)/l1b.rad1*100,s=8)
        p[0,1].set_xlabel('L1B radiance O2') 
        p[0,1].set_ylabel('(L1P-L1B/L1B*100%')
        p[0,1].grid(color='k', linestyle='--', linewidth=0.5,axis='y',which='major')
        p[1,1].scatter(l1b.rad2,(self.rad2-l1b.rad2)/l1b.rad2*100,s=8)
        p[1,1].set_xlabel('L1B radiance WCO2')
        p[1,1].set_ylabel('(L1P-L1B/L1B*100%')
        p[1,1].grid(color='k', linestyle='--', linewidth=0.5,axis='y',which='major')
        p[2,1].scatter(l1b.rad3,(self.rad3-l1b.rad3)/l1b.rad3*100,s=8)
        p[2,1].set_xlabel('L1B radiance SCO2')
        p[2,1].set_ylabel('(L1P-L1B/L1B*100%')        
        p[2,1].grid(color='k', linestyle='--', linewidth=0.5,axis='y',which='major')

        if file != None: f0.savefig(file)

    def add_l2(self,l2): # add l2 retrieval information
        self.l2=l2
        
    def plot_l2(self,file=None):
        import matplotlib
        matplotlib.use('Agg') # This ensures that figure can be made without X display
        import matplotlib.pyplot as plt 
        f0,p=plt.subplots(3,1,figsize=(7,7)); f0.subplots_adjust(hspace=0.5)
        p[0].plot(self.wl1,self.rad1)
        p[0].plot(self.l2.wl1,self.l2.radc1,label='Calculated'); p[0].set_ylabel('O2 Radiance')
        p[1].plot(self.wl2,self.rad2)
        p[1].plot(self.l2.wl2,self.l2.radc2,label='Calculated'); p[1].set_ylabel('WCO2 Radiance')
        p[2].plot(self.wl3,self.rad3)
        p[2].plot(self.l2.wl3,self.l2.radc3,label='Calculated'); p[2].set_ylabel('SCO2 Radiance')
        p[2].set_xlabel('Wavelength [$\mu$m]')
        if file != None: f0.savefig(file)

"""
most functionaliy copied from "L1P"
but tried to do this on the basis of L1B object only
"""
class L1U:
    def __init__(self,l1b,verbose=False):
        l1bf = l1b.file
        #if verbose: print2('Creating perturbed L1B file...',flush=True)
        self.l1uf = COPY_AND_RENAME(l1bf,'oco2_L1b','oco2_L1u') # creates L1b file copy as L1p file
        self.snd  = l1b.snd 
        self.rad1 = l1b.rad1
        self.rad2 = l1b.rad2
        self.rad3 = l1b.rad3    
        self.rfl1 = l1b.rfl1
        self.wl1approx=l1b.wl1approx
        self.rfl2 = l1b.rfl2
        self.wl2approx=l1b.wl2approx
        self.rfl3 = l1b.rfl3
        self.wl3approx=l1b.wl3approx
            
    def perturb(self,snd,o2=[0.,0.],wco2=[0.,0.],sco2=[0.,0.],mode='unperturb',verbose=False):
        """
        Apply simple perturbation of L1B spectrum for given snd
        o2,wco2,sco2 = [a,b]       : a,b indicate the scaling of the spectrum on the left/right end
        mode={'lambda','radiance'} : how to rescale (with respect to wavelength or radiance)
        """

        flt=np.where(np.int_(self.snd) == int(snd))
        ft = flt[0][0]
        fp = flt[1][0]
        #print('to do:',snd,' doing:',self.snd[ft,fp],ft,fp)
        print('mode='+mode)
        print('at some point, account for SZA [when in calc] + simultaneously perturb + view rescaled files')
        #plt.figure(0)
        #plt.plot(self.wl1approx[fp,:],self.rad1[ft,fp,:],'k-')
        
        if mode == 'unperturb':
            radu=self.rad1[ft,fp,:]/(1+o2[0]+o2[1]*self.rfl1[ft,fp,:])
            self.rad1[ft,fp,:]=radu.copy()
            radu=self.rad2[ft,fp,:]/(1+wco2[0]+wco2[1]*self.rfl2[ft,fp,:])
            self.rad2[ft,fp,:]=radu.copy()
            radu=self.rad3[ft,fp,:]/(1+sco2[0]+sco2[1]*self.rfl3[ft,fp,:])
            self.rad3[ft,fp,:]=radu.copy()

            
        if mode == 'perturb':    
            radsca = self.rad1[ft,fp,:]*(o2[0]+o2[1]*self.rfl1[ft,fp,:]+1)
            self.rad1[ft,fp,:]=radsca.copy()
            radsca = self.rad2[ft,fp,:]*(wco2[0]+wco2[1]*self.rfl2[ft,fp,:]+1)
            self.rad2[ft,fp,:]=radsca.copy()
            radsca = self.rad3[ft,fp,:]*(sco2[0]+sco2[1]*self.rfl3[ft,fp,:]+1)
            self.rad3[ft,fp,:]=radsca.copy()            

        self.pert_ft=ft
        self.pert_fp=fp
                           
    def substitute(self,o2=True,wco2=True,sco2=True):    
        oco = h5py.File(self.l1uf, "r+")
        if o2:
            ro2 = oco['/SoundingMeasurements/radiance_o2'][...]   # get radiances
            del(oco['/SoundingMeasurements/radiance_o2'])         # delete O2 radiance measurements
        if wco2:
            rwc = oco['/SoundingMeasurements/radiance_weak_co2'][...]   # get radiances
            del(oco['/SoundingMeasurements/radiance_weak_co2'])         # delete O2 radiance measurements
        if sco2:
            rsc = oco['/SoundingMeasurements/radiance_strong_co2'][...]   # get radiances
            del(oco['/SoundingMeasurements/radiance_strong_co2'])         # delete O2 radiance measurements            
        # find retrieval footprint
        if True:
            ft = self.pert_ft
            fp = self.pert_fp
            #print('substituting ',self.snd[ft,fp],ft,fp)
            if o2:
                ro2_mod=ro2.copy()
                #plt.figure(0)
                #plt.plot(ro2_mod[ft,fp,:],self.rad1[ft,fp,:])
                ro2_mod[ft,fp,:]=self.rad1[ft,fp,:]

                oco['/SoundingMeasurements/radiance_o2'] = ro2_mod
            if wco2:
                rwc_mod=rwc.copy()
                rwc_mod[ft,fp,:]=self.rad2[ft,fp,:]
                oco['/SoundingMeasurements/radiance_weak_co2'] = rwc_mod
            if sco2:
                rsc_mod=rsc.copy()
                rsc_mod[ft,fp,:]=self.rad3[ft,fp,:]
                oco['/SoundingMeasurements/radiance_strong_co2'] = rsc_mod
        oco.close()
        
    def reference2(self,l1b,file=None):
        import matplotlib.pylab as plt
        f0,p=plt.subplots(3,2,figsize=(7,7))
        f0.subplots_adjust(hspace=1.0)
        #f0.subplots_adjust(vspace=1.0)
        p[0,0].plot(l1b.wl1,l1b.rad1)
        p[0,0].plot(self.wl1,self.rad1)
        p[0,0].set_title(fn(self.l1pf))
        p[0,0].set_xlabel('Wavelength [micron]') 
        p[0,0].grid(color='k', linestyle='--', linewidth=0.5,axis='y',which='major')
        p[1,0].plot(l1b.wl2,l1b.rad2)
        p[1,0].plot(self.wl2,self.rad2)
        p[1,0].set_xlabel('Wavelength [micron]') 
        p[1,0].grid(color='k', linestyle='--', linewidth=0.5,axis='y',which='major')
        p[2,0].plot(l1b.wl3,l1b.rad3)
        p[2,0].plot(self.wl3,self.rad3)
        p[2,0].set_xlabel('Wavelength [micron]') 
        p[2,0].grid(color='k', linestyle='--', linewidth=0.5,axis='y',which='major')


        p[0,1].scatter(l1b.rad1,(self.rad1-l1b.rad1)/l1b.rad1*100,s=8)
        p[0,1].set_xlabel('L1B radiance O2') 
        p[0,1].set_ylabel('(L1P-L1B/L1B*100%')
        p[0,1].grid(color='k', linestyle='--', linewidth=0.5,axis='y',which='major')
        p[1,1].scatter(l1b.rad2,(self.rad2-l1b.rad2)/l1b.rad2*100,s=8)
        p[1,1].set_xlabel('L1B radiance WCO2')
        p[1,1].set_ylabel('(L1P-L1B/L1B*100%')
        p[1,1].grid(color='k', linestyle='--', linewidth=0.5,axis='y',which='major')
        p[2,1].scatter(l1b.rad3,(self.rad3-l1b.rad3)/l1b.rad3*100,s=8)
        p[2,1].set_xlabel('L1B radiance SCO2')
        p[2,1].set_ylabel('(L1P-L1B/L1B*100%')        
        p[2,1].grid(color='k', linestyle='--', linewidth=0.5,axis='y',which='major')

        if file != None: f0.savefig(file)

    def add_l2(self,l2): # add l2 retrieval information
        self.l2=l2
        
    def plot_l2(self,file=None):
        import matplotlib
        matplotlib.use('Agg') # This ensures that figure can be made without X display
        import matplotlib.pyplot as plt 
        f0,p=plt.subplots(3,1,figsize=(7,7)); f0.subplots_adjust(hspace=0.5)
        p[0].plot(self.wl1,self.rad1)
        p[0].plot(self.l2.wl1,self.l2.radc1,label='Calculated'); p[0].set_ylabel('O2 Radiance')
        p[1].plot(self.wl2,self.rad2)
        p[1].plot(self.l2.wl2,self.l2.radc2,label='Calculated'); p[1].set_ylabel('WCO2 Radiance')
        p[2].plot(self.wl3,self.rad3)
        p[2].plot(self.l2.wl3,self.l2.radc3,label='Calculated'); p[2].set_ylabel('SCO2 Radiance')
        p[2].set_xlabel('Wavelength [$\mu$m]')
        if file != None: f0.savefig(file)


############################################################################  
## For wlsub in wl, find index array of wlsubs with respect to wl
#def find_wl_idx(wlsub,wl):
#    idx=[] # index array of wlsub with respect to wl
#    dis=[] # distance of wlsub wavelengths from wl    
#    for wl0 in wlsub:
#        idx0=np.argmin(np.abs(wl0-wl))
#        idx.append(idx0)
#        dis.append(wl0-wl[idx0])
#    return(np.array(idx),np.array(dis))
############################################################################  
    
###########################################################################    
# rename parts of file names (first occurrence) and copy old to new file
def COPY_AND_RENAME(file,old,new): 
    filemod=file.replace(old,new,1)
    os.system('cp %s %s' % (file, filemod))
    return(filemod)
########################################################################### 


    
    
############################################################################    
#def SUBSTITUTE(l1p,snd,rad_sbs,rescale=None):
#    if rescale == None: rescale=1.
#    #nl=l1p[0].size
#    
#    oco = h5py.File(l1p, "r+")
#    sid = oco['/SoundingGeometry/sounding_id'][...]       # get footprint IDs
#    rad = oco['/SoundingMeasurements/radiance_o2'][...]   # get radiances
#    del(oco['/SoundingMeasurements/radiance_o2'])         # delete O2 radiance measurements
#    
#    # find retrieval footprint
#    flt=np.where(np.int_(sid) == np.int_(snd))
#    if (len(flt) == 2):
#        idx_x   = flt[0][0]
#        idx_foot= flt[1][0]
#        rad_mod=rad.copy()
#        rad_mod[idx_x,idx_foot,:]=rad_sbs[1].copy()
#        oco['/SoundingMeasurements/radiance_o2'] = rad_mod*rescale # Replace with rescaled radiance
#        success=True
#    else:
#        success=False
#    oco.close()
#    return(success)
############################################################################ 
    
def fn(file):
    pos=file.rfind('/')
    return(file[pos+1:])

    
    
        
        
